import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import OrderForm from "./components/OrderForm";
import StageSection from "./components/StageSection";
import MainDisplay from "./components/MainDisplay";
import { incrementTimeSpent } from "./features/ordersSlice";

function App() {
  const { orders } = useSelector((state) => state.orders); // Access the orders state
  const dispatch = useDispatch();

  // Increment time spent on each order every second
  useEffect(() => {
    const timer = setInterval(() => {
      dispatch(incrementTimeSpent());
    }, 1000);

    return () => clearInterval(timer); // Cleanup on component unmount
  }, [dispatch]);

  return (
    <div className="container mt-4">
      <h1 className="text-center text-primary">Pizza Shop</h1>
      {/* Form for placing new orders */}
      <OrderForm />
      <div className="row mt-4">
        {/* Display orders in various stages */}
        <StageSection orders={orders} stage="Order Placed" />
        <StageSection orders={orders} stage="Order in Making" />
        <StageSection orders={orders} stage="Order Ready" />
        <StageSection orders={orders} stage="Order Picked" />
      </div>
      {/* Main display for tracking orders */}
      <MainDisplay />
    </div>
  );
}

export default App;
