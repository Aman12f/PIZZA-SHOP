// import React from "react";
// import { useSelector } from "react-redux";

// function MainDisplay() {
//   const { orders, deliveredCount } = useSelector((state) => state.orders);

//   return (
//     <div className="mt-4">
//       <h4 className="text-center">Main Display</h4>
//       <table className="table table-striped">
//         <thead>
//           <tr>
//             <th>Order ID</th>
//             <th>Stage</th>
//             <th>Total Time Spent</th>
//             <th>Action</th>
//           </tr>
//         </thead>
//         <tbody>
//           {orders.map((order) => (
//             <tr key={order.id}>
//               <td>{order.id}</td>
//               <td>{order.stage}</td>
//               <td>{order.timeSpent} sec</td>
//               <td>
//                 {order.stage !== "Order Ready" && (
//                   <button
//                     className="btn btn-danger btn-sm"
//                     onClick={() => alert("Cancel functionality handled by PizzaCard")}
//                   >
//                     Cancel
//                   </button>
//                 )}
//               </td>
//             </tr>
//           ))}
//           <tr>
//             <td colSpan="3" className="text-end">
//               <strong>Total Orders Delivered</strong>
//             </td>
//             <td>
//               <strong>{deliveredCount}</strong>
//             </td>
//           </tr>
//         </tbody>
//       </table>
//     </div>
//   );
// }

// export default MainDisplay;


// import React from "react";
// import { useSelector } from "react-redux";

// function MainDisplay() {
//   const { orders, deliveredCount } = useSelector((state) => state.orders);

//   return (
//     <div className="mt-4">
//       <h4 className="text-center">Main Display</h4>
//       <table className="table table-striped">
//         <thead>
//           <tr>
//             <th>Order ID</th>
//             <th>Stage</th>
//             {/* <th>Time Spent in Stage</th> */}
//             <th>Total Time Spent</th>
//             <th>Action</th>
//           </tr>
//         </thead>
//         <tbody>
//           {orders.map((order) => (
//             <tr key={order.id}>
//               <td>{order.id}</td>
//               <td>{order.stage}</td>
//               {/* <td>{order.timeSpent} sec</td> */}
//               <td>{order.totalTimeSpent} sec</td>
//               <td>
//                 {order.stage !== "Order Ready" && (
//                   <button
//                     className="btn btn-danger btn-sm"
//                     onClick={() =>
//                       alert("Cancel functionality handled by PizzaCard")
//                     }
//                   >
//                     Cancel
//                   </button>
//                 )}
//               </td>
//             </tr>
//           ))}
//           <tr>
//             <td colSpan="4" className="text-end">
//               <strong>Total Orders Delivered</strong>
//             </td>
//             <td>
//               <strong>{deliveredCount}</strong>
//             </td>
//           </tr>
//         </tbody>
//       </table>
//     </div>
//   );
// }

// export default MainDisplay;

import React from "react";
import { useSelector } from "react-redux";
import { formatTime } from "../utils/utils";

function MainDisplay() {
  const { orders, deliveredCount } = useSelector((state) => state.orders);

  // Function to calculate the remaining time based on pizza size
  const calculateRemainingTime = (order) => {
    const sizeTimeMap = {
      Small: 180, // 3 minutes in seconds
      Medium: 240, // 4 minutes in seconds
      Large: 300, // 5 minutes in seconds
    };
    
    // return sizeTimeMap[order.size] - order.timeSpent;
    const remainTime =  sizeTimeMap[order.size] - order.timeSpent;
    return remainTime >= 0 ? remainTime : 0;
  };

  return (
    <div className="mt-4">
      <h4 className="text-center">Main Display</h4>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Stage</th>
            <th>Remaining Time</th>
            <th>Total Time Spent</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr key={order.id}>
              <td>{order.id}</td>
              <td>{order.stage}</td>
              <td>{formatTime(calculateRemainingTime(order))} </td>
              <td>{formatTime(order.totalTimeSpent)} </td>
              <td>
                {order.stage !== "Order Ready" && (
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() =>
                      alert("Cancel functionality handled by PizzaCard")
                    }
                  >
                    Cancel
                  </button>
                )}
              </td>
            </tr>
          ))}
          <tr>
            <td colSpan="4" className="text-end">
              <strong>Total Orders Delivered</strong>
            </td>
            <td>
              <strong>{deliveredCount}</strong>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export default MainDisplay;

