import React from "react";
import PizzaCard from "./PizzaCard";

function StageSection({ orders, stage }) {
  return (
    <div className="col">
      <h5 className="text-center">{stage}</h5>
      {orders
        .filter((order) => order.stage === stage)
        .map((order) => (
          <PizzaCard key={order.id} order={order} />
        ))}
    </div>
  );
}

export default StageSection;
